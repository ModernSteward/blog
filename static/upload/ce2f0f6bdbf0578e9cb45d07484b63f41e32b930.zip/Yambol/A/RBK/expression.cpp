#include<iostream>
using namespace std;

long long  st[128],n,k;

int main()
{
long long i,j;
cin>>n>>k;
st[1]=0;
for(i=2;i<=k;i++)
 st[i]=1;
for(i=3;i<=n;i++)
{
for(j=2;j<=k;j++)
 if(j<i)
  st[i]=st[i]+st[i-j];
for(j=2;j<=k;j++)
 if( ( i%j == 0 ) && (j<i)  )
  st[i] = st[i] + st[i/j];
}

cout<<st[n]<<endl;

return 0;
}
