#include<iostream>
using namespace std;


int ko[16384],h[16384],r[16384],n,k;
int re[16384];

int f(int i , int j)
{
int k;
if(j==i+1)
return 1;
for(k=i+1;k<=j-1;k++)
 {
   if( (h[j]-h[i]) * (r[k]-r[i]) <= (h[k]-h[i]) * (r[j]-r[i]) )
  return 0;
 }
return 1;
}

int main()
{
int i,j;
cin>>n>>k;
for(i=1;i<=n;i++)
scanf("%d%d",&r[i],&h[i]);

for(i=1;i<=n;i++)
ko[i]= h[i]*r[i];
int uk=1;
re[1]=1;

while(re[uk]!=n)
{
 i=re[uk]+1;
 int bst=i,bstko=ko[i];
 i++;
 while((r[i]-r[uk])<=k)
 {
  if(f(re[uk],i))
   if(ko[i]>bstko)
   {
    bst=i;
    bstko=ko[i];
   }
  i++;
 }
 uk++;
 re[uk]=bst;
}
cout<<uk<<endl;
//for(i=1;i<=uk;i++)
 //cout<<re[i]<<' ';
//cout<<endl;
//for(i=1;i<=n;i++)
 //cout<<r[i]<<' '<<h[i]<<endl;
return 0;
}
