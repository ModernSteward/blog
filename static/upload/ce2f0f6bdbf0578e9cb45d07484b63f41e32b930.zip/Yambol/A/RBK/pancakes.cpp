#include<iostream>
using namespace std;

long long t[32],n,x;

int main()
{
cin>>x>>n;
long long  i,j;
for(i=1;i<=n;i++)
cin>>t[i];

long long d=0;
long long maxt=0;
for(i=1;i<=n;i++)
 if(maxt<t[i])
  maxt=t[i];

d= x/n + 1;
d=d*maxt;
long long l=1;
long long otg;
while(l<d)
{
long long sr= (l+d)/2;
long long pal=0;
for(i=1;i<=n;i++)
 pal = pal + sr/t[i];
if(pal<x)
 l=sr+1;
else
 { d=sr; otg=sr; }
}
cout<<otg<<endl;

return 0;
}
