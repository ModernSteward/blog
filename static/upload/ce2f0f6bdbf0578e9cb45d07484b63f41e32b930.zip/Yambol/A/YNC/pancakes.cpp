#include <cstdio>

int n;
long long x;
long long t[32];

int main()
{
	int i;
	long long l, r, m;
	long long sm;
	
	scanf( "%lld %d", &x, &n );
	for ( i = 1; i <= n; i++ )
	{
		scanf( "%lld", &t[i] );
	}
	
	l = 0; r = (1LL<<62);
	while ( l+1 < r )
	{
		m = (l+r)/2;
		sm = 0;
		for ( i = 1; i <= n; i++ )
		{
			sm = sm + m/t[i];
		}
		if ( sm >= x ) r = m;
		else l = m;
	}
	printf( "%lld\n", r );
	return 0;
}
