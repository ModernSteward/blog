#include <cstdio>
#include <cstring>

int n, k;
long long dp[1024];

long long getDP( int x )
{
	if ( x == 0 ) return 1;
	if ( dp[x] != -1 ) return dp[x];

	long long sol = 0;
	for ( int la = 2; la <= k; la++ )
	{
		if ( x % la == 0 )
			sol = sol + getDP( x/la );
		if ( x >= la )
			sol = sol + getDP( x-la );
	}
	
	dp[x] = sol;
	return dp[x];
}

int main()
{
	memset( dp, -1, sizeof( dp ) );
	scanf( "%d %d", &n, &k );
	printf( "%lld\n", getDP( n ) );
	return 0;
}
