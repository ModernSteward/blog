#include <cstdio>
#include <cstring>

struct drob
{
	long long x, y;
	bool operator<( const drob &a ) const
	{
		return (x*a.y - y*a.x < 0);
	}
};

inline drob md( long long x, long long y )
{
	drob d;
	d.x = x;
	d.y = y;
	return d;
}

int n, k;
int x[16000], h[16000];

int dp[16000];

int getDP( int y )
{
	if ( y < 1 ) return 0;
	if ( y == 1 ) return 1;
	if ( dp[y] != -1 ) return dp[y];
	
	int sol = (1<<29);
	drob mx; mx.x = -(1<<29); mx.y = 1;
	for ( int i = y-1; i > 0 && x[i] + k >= x[y]; i-- )
	{
		if ( mx < md( h[i]-h[y], x[y]-x[i] ) )
		{
			mx = md( h[i]-h[y], x[y]-x[i] );
			if ( sol > getDP( i ) + 1 )
				sol = getDP( i ) + 1;
		}
	}
	
	dp[y] = sol;
	return dp[y];
}

int main()
{
	int i;
	
	scanf( "%d %d", &n, &k );
	for ( i = 1; i <= n; i++ )
		scanf( "%d %d", &x[i], &h[i] );
	
	memset( dp, -1, sizeof( dp ) );
	printf( "%d\n", getDP( n ) );
	return 0;
}
