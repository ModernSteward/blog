#include <iostream>
#include <algorithm>
using namespace std;
struct aws
{
    string bashta,sin;
};
bool sorthelpersin(aws a,aws b)
{
    int leng;
    leng=a.sin.length();
    if (leng>b.sin.length())
    leng=b.sin.length();
    int i;
    for (i=0;i<leng;i++)
    {
        if (a.sin[i]!=b.sin[i]) return (a.sin[i]<b.sin[i]);
    }
    return (a.sin.length()<b.sin.length());
    
}
bool sorthelperbashta (aws a,aws b)
{
    int leng;
    leng=a.bashta.length();
    if (leng>b.bashta.length())
    leng=b.bashta.length();
    int i;
    for (i=0;i<leng;i++)
    {
        if (a.bashta[i]!=b.bashta[i]) return (a.bashta[i]<b.bashta[i]);
    }
    return (a.bashta.length()<b.bashta.length());
    
}
bool sravnqvane(string a,string b)
{
    int leng;
    leng=a.length();
    if (leng>b.length())
    leng=b.length();
    int i;
    for (i=0;i<leng;i++)
    {
        if (a[i]!=b[i]) return (a[i]<b[i]);
    }
    return (a.length()<b.length());
}
int main ()
{
    bool flag1=false,flag2=false;
    aws work[10002];
    aws copy[10002];
    int condition=0;
    string TFO[10002];
    int n;
    int answer=0;
    bool breakche=false;
    int i,j;
    int tfoleng=0;
    int index=1;
    int minind=99999999;
    cin>>n;
    for (i=1;i<=n;i++)
    {
        cin>>work[i].bashta>>work[i].sin;
        copy[i]=work[i];
    }
    sort(work+1,work+n+1,sorthelpersin);
    for (i=1;i<n;i++)
    {
        if (work[i].sin==work[i+1].sin&&work[i].bashta!=work[i+1].bashta)
        {
            flag1=true;
            TFO[index]=work[i].sin;
            tfoleng++;
        }
    }
    if (flag1)
    {
        for (i=1;i<=n;i++)
        {
            for (j=i;j<=n;j++)
            {
                if (copy[i].sin==copy[j].sin&&copy[i].bashta!=copy[j].bashta)
                {
                    cout<<copy[i].sin<<endl;
                    return 0;
                }
            }
        }
    }    
    return 0;
}