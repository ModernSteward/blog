#include <iostream>
#include <algorithm>
using namespace std;

int main ()
{
    bool work[10002];
    bool check[10002];
    unsigned long long arr[102];
    unsigned long long i,j,n,a,b;
    unsigned long long answer=0;
    unsigned long long in1;
    bool flag=false;
    cin>>n>>a>>b;
    for (i=0;i<10002;i++) 
    {
        work[i]=false;
        check[i]=false;
    }
    for (i=1;i<=n;i++) 
    {
        cin>>in1;
        arr[i]=in1;
        work[in1]=true;
        check[in1]=true;
    }
    sort(arr+1,arr+n+1);
    i=0;
    while (!flag)
    {
        flag=true;
        i++;
        for (j=10002;j>=1;j--)
        {
            if (arr[i]!=j&&work[j]&&j+arr[i]>=a&&j+arr[i]<=b&&work[j+arr[i]]==false) 
            {
                work[j+arr[i]]=true;
                flag=false;
            }
        }
    }
    for (i=a;i<=b;i++) 
    {
        if (work[i]) 
        {
            answer++;
        }
    }
    cout<<answer<<endl;
    return 0;
}