#include <iostream>
using namespace std;

int main ()
{
    unsigned long long deliteli[16]{2,3,5,7,11,13,17,19,23,29,31,37,41,43,47};
    unsigned long long arr[46];
    unsigned long long nok=1;
    unsigned long long max=0;
    unsigned long long i,j,n;
    unsigned long long chisliteli[46];
    bool flagZ;
    bool flag;
    cin>>n;
    unsigned long long cqlo=0,chisl=0,znam=0;
    for (i=1;i<=n;i++) arr[i]=i;
    max=n;
    int index=0;
    while (max>=deliteli[index])
    {
        flag=true;
        while (flag)
        {
            flag=false;
            for (i=1;i<=n;i++)
            {
                flagZ=false;
                if (arr[i]%deliteli[index]==0)
                {
                    arr[i]/=deliteli[index];
                    flag=true;
                    flagZ=true;
                }
            }
            if (flag) nok*=deliteli[index];
        }
        max=0;
        for (i=1;i<=n;i++) if (max<arr[i]) max=arr[i];
        index++;
    }
    znam=nok;
    for (i=1;i<=n;i++)
    {
        chisliteli[i]=nok/i;
    }
    for (i=1;i<=n;i++)
    {
        chisl+=chisliteli[i];
        if (chisl>znam)
        {
            cqlo+=chisl/znam;
            chisl-=znam*(chisl/znam);
        }
    }
    cqlo+=chisl/znam;
    chisl-=znam*(chisl/znam);
    cout<<cqlo<<" "<<chisl<<" "<<znam<<endl;
    return 0;
}