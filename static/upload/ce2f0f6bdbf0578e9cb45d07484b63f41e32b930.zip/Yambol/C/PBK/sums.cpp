#include<iostream>
#include<algorithm>
using namespace std;
long long n,a,b,sum,br;
int o[1000005],m[1005];

bool proverka()
{
  long long i;

  for(i=2;i<=n;i++)
    if(m[i-1] < m[i])
      return 0;

  return 1;
}

int main()
{
  long long i;

  cin>>n>>a>>b;

  for(i=1;i<=n;i++)
    cin>>m[i];

  sort(m+1,m+n+1);

  while(1)
  {
    sum = 0;

    for(i = 1; i <= n; i++)
    {
      sum += m[i];
      if(sum >= a)
        if(sum <= b)
        {
          if(o[sum] == 0)
          {
            o[sum] = 1;
            br++;
          }
        }
        else
          break;
    }

    if(proverka() == 0)
      next_permutation(m+1,m+n+1);
    else
      break;
  }

  cout<<br<<endl;
}
