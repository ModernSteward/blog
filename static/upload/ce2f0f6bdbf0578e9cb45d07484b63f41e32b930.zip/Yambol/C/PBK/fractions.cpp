#include<iostream>
using namespace std;
long long n,ch,z;

long long nod(long long x, long long y)
{
  while(1)
  {
    if(x > y)
      x = x%y;
    else
      y = y%x;

    if(x == 0)
      return y;
    if(y == 0)
      return x;
  }
}

int main()
{
  long long i,pom;

  cin>>n;

  ch = 1;
  z = 1;

  for(i = 2; i <= n; i++)
  {
    ch = ch*i + z;
    z = i*z;
    pom = nod(ch,z);
    ch /= pom;
    z /= pom;
  }

  cout<<ch/z<<" "<<ch%z<<" "<<z<<endl;
}
