#include<iostream>
#include<string>
#include<algorithm>
using namespace std;
int n,br,b[20005],m[2005][2005],ns[20005],v,maxx;
string a[20005],x,y,ans;

bool proverka(string s1, string s2)
{
  int i,p;

  if(s1.length() < s2.length())
    p = s1.length();
  else
    p = s2.length();

  for(i=0;i<=p-1;i++)
  {
    if(s1[i] > s2[i])
      return 1;

    if(s2[i] > s1[i])
      return 0;
  }

  if(s1.length() < s2.length())
    return 0;
  return 1;
}


bool rec(int t)
{
  long long i;

  if(m[t][0] == 0)
    return 0;

    ns[v] += m[t][0];

  for(i=1;i<=m[t][0];i++)
    rec(m[t][i]);
}

int main()
{
  long long ix,iy,i,j,fl = 0,p;
  cin>>n;
  for(i=1;i<=n;i++)
  {
    ix = 0;
    iy = 0;
    cin>>x>>y;

    for(j=1;j<=br;j++)
    {
      if(a[j] == x)
        ix = j;
      if(a[j] == y)
        iy = j;
    }

    if(ix == 0)
    {
      br++;
      a[br] = x;
      ix = br;
    }

    if(iy == 0)
    {
      br++;
      a[br] = y;
      iy = br;
    }

    if(b[iy] != 0 && b[iy] != ix && fl == 0)
    {
      ans = a[iy];
      fl = 1;
    }
    else
      b[iy] = ix;

    m[ix][0]++;
    m[ix][m[ix][0]] = iy;
  }

  if(fl == 0)
    for(i=1;i<=br;i++)
    {
      v = i;
      rec(v);
      if(ns[v] > maxx && proverka(a[v],ans) == 1)
      {
        maxx = ns[v];
        ans = a[v];
      }
    }

  cout<<ans<<endl;
}
/*
10
aa ba
iaa ha
de da
ca aa
ga ca
ha bc
bc bd
ia de
da vo
da vo
*/
