#include <iostream>
using namespace std;
int mnojiteli[50];
int currmnojiteli[50];

void getmnojiteli(int k)
{
    int i;
    for (i=2;i<=k;i++)
    {
        while(k%i==0)
        {
            mnojiteli[i]++;
            k=k/i;
        }
    }
    return;
}

int main()
{
    unsigned long long znamenatel,chislitel,num;
    unsigned long long cqlachast;
    cqlachast=1;
    chislitel=0;
    znamenatel=1;
    unsigned long long n;
    unsigned long long i,j,in;
    cin>>n;
    for (i=1;i<=49;i++)
    {
        currmnojiteli[i]=0;
    }
    for (i=2;i<=n;i++)
    {
        num=1;
        for (j=1;j<=49;j++)
        {
            mnojiteli[j]=0;
        }
        getmnojiteli(i);
        for (j=1;j<=49;j++)
        {
            if (mnojiteli[j]>currmnojiteli[j])
            {
                for (in=1;in<=mnojiteli[j]-currmnojiteli[j];in++)
                {
                    znamenatel=znamenatel*j;
                    chislitel=chislitel*j;
                }
                currmnojiteli[j]=mnojiteli[j];
            }
            
            if (mnojiteli[j]<currmnojiteli[j])
            {
                for (in=1;in<=currmnojiteli[j]-mnojiteli[j];in++)
                {
                    num=num*j;
                }
            }
            if (chislitel>=znamenatel)
            {
                cqlachast+=chislitel/znamenatel;
                chislitel=chislitel%znamenatel;
            }
        }
        chislitel=chislitel+num;
        if (chislitel>=znamenatel)
        {
            cqlachast+=chislitel/znamenatel;
            chislitel=chislitel%znamenatel;
        }
    }
    cout<<cqlachast<<" "<<chislitel<<" "<<znamenatel<<endl;
    return 0;
}