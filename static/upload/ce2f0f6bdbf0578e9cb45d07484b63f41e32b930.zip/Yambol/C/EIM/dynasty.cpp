#include <iostream>
#include <algorithm>
using namespace std;
struct family
{
    int sonn,daddy,orgind;
};
struct dyn
{
    int human,son;
};

int kids[27][27][27][27][27];
family sonslist[10001];
dyn dynasty[10001];
int n;

bool sorty(family a,family b)
{
    return (a.sonn<b.sonn);
}
bool sorty2(dyn a,dyn b)
{
    if (a.human<b.human)
    return true;
    else if (a.human>b.human)
    return false;
    else
    {
        return (a.son<b.son);
    }
}

int convert(string a)
{
    int num=0;
    int i;
    for (i=0;i<a.length();i++)
    {
        num=num*100+( (int)a[i]-50 );
    }
    return num;
}

string deconvert(int a)
{
    string str="";
    string strc="";
    char ch;
    int i;
    while (a>0)
    {
        ch=(char)( (a%100)+50 );
        strc=strc+ch;
        a=a/100;
    }
    for (i=strc.length()-1;i>=0;i--)
    {
        str=str+strc[i];
    }
    return str;
}

int finditfirst(int ms)
{
    int l=1;
    int r=n;
    int mid;
    while (l<r)
    {
        mid=(l+r)/2;
        if (sonslist[mid].sonn<ms)
        l=mid+1;
        if (sonslist[mid].sonn>ms)
        r=mid-1;
        if (sonslist[mid].sonn==ms)
        {
            if (sonslist[mid-1].sonn==ms)
            r=mid-1;
            else
            return mid;
        }
    }
    return -1;
}

void add1to(int k)
{
    int ch[5],d;
    int uk=-1;
    int i;
    while (k>0)
    {
        uk++;
        ch[uk]=(k%100)-46;
        k=k/100;
    }
    for (i=0;i<=uk/2;i++)
    {
        d=ch[i];
        ch[i]=ch[uk-i];
        ch[uk-i]=d;
    }
    for(i=uk+1;i<=4;i++)
    {
        ch[i]=0;
    }
    kids[ch[0]][ch[1]][ch[2]][ch[3]][ch[4]]++;
    return;
}

void add1(int k)
{
    int uk=k;
    int currdad=-1;
    while (sonslist[uk].sonn==sonslist[k].sonn)
    {
        if (sonslist[uk].daddy!=currdad)
        {
            currdad=sonslist[uk].daddy;
            add1to(sonslist[uk].daddy);
            if (finditfirst(sonslist[uk].daddy)!=-1)
            {
                add1( finditfirst(sonslist[uk].daddy) );
            }
        }
        uk++;
    }
}

int main()
{
    int i,j,in,ja,inn;
    int minindex=99999,minnow,mistaken;
    int maxnum;
    int currdad,currson;
    string dad,son;
    string maxone;
    int cdad,cson;
    cin>>n;
    
    for (i=1;i<=26;i++)
    {
        for (j=1;j<=26;j++)
        {
            for (in=1;in<=26;in++)
            {
                for (ja=1;ja<=26;ja++)
                {
                    for (inn=1;inn<=26;inn++)
                    {
                        kids[i][j][in][ja][inn]=0;
                    }
                }
            }
        }
    }
    
    dynasty[0].human=0;
    /*for (i=1;i<=10000;i++)
    {
        dynasty[i].kids=-1;
    }*/
    for (i=1;i<=n;i++)
    {
        cin>>dad;
        cin>>son;
        cdad=convert(dad);
        cson=convert(son);
        
        sonslist[i].sonn=cson;
        sonslist[i].daddy=cdad;
        sonslist[i].orgind=i;
        
        dynasty[i].human=cdad;
        dynasty[i].son=cson;
    }
    sort(sonslist+1,sonslist+1+n,sorty);
    sort(dynasty+1,dynasty+1+n,sorty2);
    currson=sonslist[1].sonn;
    currdad=sonslist[1].daddy;
    minnow=sonslist[1].orgind;
    for (i=1;i<=n;i++)
    {
        if (sonslist[i].sonn==currson)
        {
            if(sonslist[i].orgind<minnow)
            minnow=sonslist[i].orgind;
            
            if (sonslist[i].daddy!=currdad)
            {
                if (minnow<minindex)
                {
                   minindex=minnow;
                   mistaken=sonslist[i].sonn;
                }
            }
        }
        else
        {
            currson=sonslist[i].sonn;
            currdad=sonslist[i].daddy;
        }
    }
    if (minindex!=99999)
    {
        cout<<deconvert(mistaken)<<endl;
        return 0;
    }
    cout<<deconvert(dynasty[n].human)<<endl;
    return 0;
    
}