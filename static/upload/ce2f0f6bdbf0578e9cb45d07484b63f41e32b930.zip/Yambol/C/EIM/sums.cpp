#include <iostream>
using namespace std;
bool possibles[10002];
int nums[102];
int main()
{
    int i,j;
    int n,a,b;
    int ctr=0;
    cin>>n>>a>>b;
    for (i=1;i<=10000;i++)
    {
        possibles[i]=false;
    }
    for (i=1;i<=n;i++)
    {
        cin>>nums[i];
    }
    possibles[0]=true;
    for (i=1;i<=n;i++)
    {
        for (j=10000;j>=0;j--)
        {
            if (possibles[j])
            {
                possibles[j+nums[i]]=true;
            }
        }
    }
    for (i=a;i<=b;i++)
    {
        if (possibles[i])
        ctr++;
    }
    cout<<ctr<<endl;
    return 0;
}