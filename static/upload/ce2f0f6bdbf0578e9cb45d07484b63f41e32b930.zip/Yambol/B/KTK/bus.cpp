#include<iostream>
using namespace std;

struct aaa
{
   int l;
   int r;
   int p;
}s[10009];

bool sorting(aaa a, aaa b)
{
   if(a.r>b.r)
   {
      return 0;
   }
   else
   {
      if(a.r<b.r)
      {
         return 1;
      }
      else
      {
         if(a.l>b.l)
         {
            return 0;
         }
         else
         {
            if(a.l==b.l)
            {
               if(a.p>b.p)
               {
                  return 0;
               }
               else
               {
                  return 1;
               }
            }
            else
            {
               return 1;
            }
         }
      }
   }
}

int main()
{
   int i,n,a,b,l,r,p,cena[10055];
   cin>>n>>a>>b;
   for(i=1;i<=n;i++)
   {
      cin>>s[i].l>>s[i].r>>s[i].p;
   }
   sort(s+1,s+n+1,sorting);
   int uk=1;
   for(i=0;i<=a;i++)
   {
      cena[i]=0;
   }
   for(i=a+1;i<=b;i++)
   {
      cena[i]=1000005;
   }
   for(i=1;i<=n;i++)
   {
      if(s[i].r>b)
      {
         if(s[i].l<b)
         {
            s[i].r=b;
         }
      }
   }
   for(i=a;i<=b;i++)
   {
      while(s[uk].r==i)
      {
         if(s[uk].r==i)
         {
            if(s[uk].p+cena[s[uk].l]<cena[i])
            {
               cena[i]=s[uk].p+cena[s[uk].l];
            }
         }
         uk++;
      }
      if(cena[i]>=cena[i-1]+1)
      {
         cena[i]=cena[i-1]+1;
      }
   }
   cout<<cena[b]<<endl;
   return 0;
}
