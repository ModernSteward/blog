#include<iostream>
using namespace std;

struct vrah
{
   int x;
   int y;
}dl[105],gd[105];

int a,b,c;

void uravnenie(int x, int y, int xx, int yy)
{
   a=y-yy;
   b=xx-x;
   c=-1*((a*x)+(b*y));
}

int proverka(int x, int y)
{
   if(a*x+b*y+c>=0)
   {
      if(a*x+b*y+c==0)
      {
         return 11;
      }
      else
      {
         return 2;
      }
   }
   else
   {
      return 1;
   }

}


int obshta_tochka(int a,int b)
{
   int ii,i,jj,j,x[9],y[9];
   x[1]=dl[a].x;
   y[1]=dl[a].y;

   x[3]=gd[a].x;
   y[3]=gd[a].y;

   x[2]=dl[a].x;
   y[2]=gd[a].y;

   x[4]=gd[a].y;
   y[4]=dl[a].x;

   x[5]=dl[b].x;
   y[5]=dl[b].y;

   x[7]=gd[b].x;
   y[7]=gd[b].y;

   x[6]=dl[b].x;
   y[6]=gd[b].y;

   x[8]=gd[b].y;
   y[8]=dl[b].x;

   for(i=1;i<4;i++)
   {
      for(ii=i+1;ii<=4;ii++)
      {
         for(j=5;j<8;j++)
         {
            for(jj=j+1;jj<=8;jj++)
            {
               uravnenie(x[i],y[i],x[ii],y[ii]);
               if(proverka(x[j],y[j])!=proverka(x[jj],y[jj]))
               {
                  uravnenie(x[j],y[j],x[jj],y[jj]);
                  if(proverka(x[i],y[i])!=proverka(x[ii],y[ii]))
                  {
                     return 1;
                  }
                  else
                  {
                     if((proverka(x[i],y[i])==11)||(proverka(x[ii],y[ii])==11))
                     {
                        return 1;
                     }
                  }
               }
            }
         }
      }
   }
   return 0;
}

int main()
{
   int n,x1,x2,y1,y2,i,j,s1,p;
   int hx[8],hy[8];
   unsigned long long int s=0;
   cin>>n;
   for(i=1;i<=n;i++)
   {
      cin>>x1>>y1>>x2>>y2;
      if(x1<x2)
      {
         dl[i].x=x1;
         gd[i].x=x2;
      }
      else
      {
         dl[i].x=x2;
         gd[i].x=x1;
      }

      if(y1<y2)
      {
         dl[i].y=y1;
         gd[i].y=y2;
      }
      else
      {
         dl[i].y=y2;
         gd[i].y=y1;
      }
      s=s+(abs(gd[i].x-dl[i].x))*(abs(gd[i].y-dl[i].y));
   }

   for(i=1;i<=n;i++)
   {
      for(j=i+1;j<=n;j++)
      {
         if(obshta_tochka(i,j)==1)
         {
            hx[1]=dl[i].x;
            hx[2]=gd[i].x;
            hx[3]=dl[j].x;
            hx[4]=gd[j].x;

            hy[1]=dl[i].y;
            hy[2]=gd[i].y;
            hy[3]=dl[j].y;
            hy[4]=gd[j].y;

            sort(hy+1,hy+5);
            sort(hx+1,hx+5);

            s1=(hy[3]-hy[2])*(hx[3]-hx[2]);
            s=s-s1;
         }
      }
   }
   cout<<s<<endl;
   return 0;
}
