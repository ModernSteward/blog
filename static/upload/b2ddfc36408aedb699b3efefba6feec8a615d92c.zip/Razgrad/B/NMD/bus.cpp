#include<iostream>
#include<vector>
using namespace std;


struct dis{
int x,s;    
};

int n,a,b;
int maxN=-1;
vector<dis> roads[10000];//////////////////////////// 

int minDis[10000];
vector<dis> unpassed;



int dejkstra(){
    dis d1;
    int x,y,s;
    
    
    while(!unpassed.empty()){
        
        x=unpassed[0].x;
        s=unpassed[0].s;
        
        unpassed.erase(unpassed.begin()+1);
        
        
        
        for(int i=0;i<roads[x].size();i++){
            
            if(minDis[roads[x][i].x]>=s+roads[x][i].s){
                d1.x=roads[x][i].x;
                d1.s=s+roads[x][i].s;
                unpassed.push_back(d1);
                
                if(roads[x][i].x-x>1)
                for(int j=x+roads[x][i].s;j<=roads[x][i].x;j++){minDis[j]=s+roads[x][i].s;}
            }
            
        }
        
        
        
        
    }
    cout<<minDis[b];
    
    
}








void init(){
    
    dis d1; d1.s=1;
    for(int i=1;i<maxN;i++){
        d1.x=i+1;
        roads[i].push_back(d1);
        
        minDis[i]=i-a;
        
    }    
    
    
}
void read(){
    cin>>n>>a>>b;
    
    int x,y,s;
    dis d1;
    for(int i=0;i<n;i++){
        cin>>x>>y>>s;
        if(x>maxN)maxN=x;
        if(y>maxN)maxN=y;
        
        d1.x=y;d1.s=s;
        roads[x].push_back(d1);
        
    }
    init();
    
}







void check(){
    for(int i=0;i<maxN;i++){
        cout<<i<<":";
        for(int j=0;j<roads[i].size();j++){
            cout<<roads[i][j].x<<"="<<roads[i][j].s<<", ";    
        }cout<<"\n";
    }
    
    for(int i=0;i<maxN;i++){
        cout<<i<<"--"<<minDis[i]<<"\n";
    }
    
    
}



int main(){
    read();
    
    dis d1;
    
    d1.x=a; d1.s=0; minDis[a]=0;
    
    unpassed.push_back(d1);
    
    dejkstra();
    
   //check();


return 0;    
}
