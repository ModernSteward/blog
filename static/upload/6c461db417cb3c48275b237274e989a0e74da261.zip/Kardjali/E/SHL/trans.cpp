#include<iostream>
using namespace std;
int main()
{
    int k,n,br=0,a,b;
    long m;
    cin >> k >> n >> m;
    for(int i=1;i<=m;i++)
    {
       cin >> a >> b;
       if(a==k)br++;
    }
    cout << br;
    system("pause");
    return 0;
}
    
