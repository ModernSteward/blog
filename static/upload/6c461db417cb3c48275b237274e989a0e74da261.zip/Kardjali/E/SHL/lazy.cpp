#include<iostream>
using namespace std;
int main()
{
    char c;
    long n;
    cin >> n;
    for(int i=1;i<=n;i++)
    {
            cin.get(c);
            if(c!='a' && c!='b' && c!='d' && c!='e' && c!='g' && c!='o' && c!='p' && c!='q' && c!=' ')
            cout <<c;
    }
    system("pause");
    return 0;
}
