#include<iostream>
using namespace std;
char s[101];
int i;
void output_s(int x)
{
 for(int j=1;j<=x;j++)
     cout<<s[j];
}
int input_s()
{
     i=0;
     do
     {
         i++;
         cin.get(s[i]);
              
     }
     while(s[i]!='\n'); 
     return i;
}
int main()
{
    input_s();
    output_s(i);
    system("pause");
    return 0;
}

    
