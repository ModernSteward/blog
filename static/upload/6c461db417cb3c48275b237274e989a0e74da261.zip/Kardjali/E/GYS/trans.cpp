#include <iostream>
using namespace std;
int main()
{
    long long m;
    int br=0, k, n, city1, city2;
    cin>>k>>n>>m;
    for(int i=1;i<=m;i++)
    {
    cin>>city1>>city2;
    if(city1==k)
    br++;
    }
    cout<<br;
    return 0;
}
