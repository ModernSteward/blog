#include <iostream>
using namespace std;
int main()
{
    long n;
    char ch;
    cin>>n;
    for(int i=1;i<=n;i++)
    {
    cin.get(ch);
    if(ch!='a' && ch!='b' && ch!='d' && ch!='e' && ch!='g' && ch!='o' && ch!='p' && ch!='q' && ch!=' ')
    cout<<ch;
    return 0;
    }



