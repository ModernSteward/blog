#include<iostream>
using namespace std;
int main()
{
    int n,k,c,d,B=0;
    long m;
    cin>>k>>n>>m;
    for(int i=1;i<=m;i++){
    cin>>c>>d;
    if(c==k)B++;
    }
    cout<<B;
    system("pause");
    return 0;
}
