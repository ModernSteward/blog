#include<iostream>
using namespace std;
int main()
{
    long a;
    char n;
    cin>>a;
    for(int i=1;i<=a;i++){
    cin.get(n);
    if(n!='a' && n!='b' && n!='d' && n!='e' && n!='g' && n!='o' && n!='p' && n!='q' && n!=' ')
    cout<<n;
    }
    system("pause");
    return 0;
}
